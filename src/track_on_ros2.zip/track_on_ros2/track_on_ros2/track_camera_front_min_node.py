#!/usr/bin/env python3
"""
ROS2节点：前端摄像头最简关键点跟踪（仅2D像素坐标）

根据 track_camera_front_node.py 精简：
- 移除3D计算（深度、相机内参）
- 移除坐标系转换（TF）
- 仅保留：订阅图像、交互选择点、跟踪、发布2D像素坐标(x,y)
- 默认订阅图像话题：/left/color/video
"""

import os
import sys
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from std_msgs.msg import Header
import matplotlib.pyplot as plt

# 查找并导入 track_on/tracking_module

def find_track_on_path():
    current_file_dir = os.path.dirname(os.path.abspath(__file__))
    path = current_file_dir
    for _ in range(10):
        src_track_on = os.path.join(path, 'src', 'track_on')
        if os.path.isdir(src_track_on) and os.path.isfile(os.path.join(src_track_on, 'tracking_module.py')):
            return src_track_on
        if os.path.basename(path) == 'src':
            track_on = os.path.join(path, 'track_on')
            if os.path.isdir(track_on) and os.path.isfile(os.path.join(track_on, 'tracking_module.py')):
                return track_on
        parent = os.path.dirname(path)
        if parent == path:
            break
        path = parent
    for env_var in ['AMENT_PREFIX_PATH', 'COLCON_PREFIX_PATH']:
        env_path = os.environ.get(env_var, '')
        if env_path:
            for prefix_path in env_path.split(':'):
                if 'tracking_with_cameara_ws' in prefix_path:
                    ws_root = prefix_path[:prefix_path.index('tracking_with_cameara_ws') + len('tracking_with_cameara_ws')]
                    src_track_on = os.path.join(ws_root, 'src', 'track_on')
                    if os.path.isdir(src_track_on) and os.path.isfile(os.path.join(src_track_on, 'tracking_module.py')):
                        return src_track_on
    cwd = os.getcwd()
    if 'tracking_with_cameara_ws' in cwd:
        ws_root = cwd[:cwd.index('tracking_with_cameara_ws') + len('tracking_with_cameara_ws')]
        src_track_on = os.path.join(ws_root, 'src', 'track_on')
        if os.path.isdir(src_track_on) and os.path.isfile(os.path.join(src_track_on, 'tracking_module.py')):
            return src_track_on
    known_path = '/home/root1/Corenetic/code/project/tracking_with_cameara_ws/src/track_on'
    if os.path.isdir(known_path) and os.path.isfile(os.path.join(known_path, 'tracking_module.py')):
        return known_path
    return None

track_on_path = find_track_on_path()
if track_on_path and track_on_path not in sys.path:
    sys.path.insert(0, track_on_path)

from tracking_module import TrackingModule  # noqa: E402


class TrackCameraFrontMinNode(Node):
    """ROS2节点：订阅前端摄像头颜色图像话题进行关键点跟踪（仅2D像素坐标）。"""

    def __init__(self):
        super().__init__('track_camera_front_min_node')

        # 参数
        self.declare_parameter('checkpoint_path', '')
        self.declare_parameter('camera_topic', '/left/color/video')
        self.declare_parameter('publish_visualization', True)
        self.declare_parameter('show_interactive_window', True)
        # 实时打印2D坐标控制
        self.declare_parameter('print_xy', True)
        self.declare_parameter('print_xy_interval', 1)  # 每N帧打印一次

        checkpoint_path = self.get_parameter('checkpoint_path').get_parameter_value().string_value
        camera_topic = self.get_parameter('camera_topic').get_parameter_value().string_value
        publish_visualization = self.get_parameter('publish_visualization').get_parameter_value().bool_value
        show_interactive_window = self.get_parameter('show_interactive_window').get_parameter_value().bool_value
        print_xy = self.get_parameter('print_xy').get_parameter_value().bool_value
        print_xy_interval = self.get_parameter('print_xy_interval').get_parameter_value().integer_value

        # 保存打印参数
        self.print_xy = print_xy
        self.print_xy_interval = max(1, int(print_xy_interval) if isinstance(print_xy_interval, int) else 1)
        self.print_xy_counter = 0

        if not checkpoint_path or not os.path.isfile(checkpoint_path):
            self.get_logger().error(f'检查点文件不存在: {checkpoint_path}')
            raise FileNotFoundError(f'检查点文件不存在: {checkpoint_path}')

        # 初始化跟踪器
        self.get_logger().info(f'正在加载模型检查点: {checkpoint_path}')
        self.tracker = TrackingModule(checkpoint_path)
        self.get_logger().info('模型加载成功')

        # 状态
        self.bridge = CvBridge()
        self.selected_points: list[list[float]] = []
        self.tracking_started = False
        self.first_frame_captured = False
        self.frame_count = 0
        self.current_frame = None
        self.colors = self._generate_colors(100)
        self.show_interactive_window = show_interactive_window
        self.window_name = "Front Camera Minimal Tracking - Click points, SPACE start, Q quit"
        self.should_exit = False

        # 订阅图像
        self.get_logger().info(f'订阅前端摄像头颜色图像话题: {camera_topic}')
        self.image_sub = self.create_subscription(
            Image,
            camera_topic,
            self.image_callback,
            qos_profile_sensor_data
        )

        # 发布关键点
        try:
            from track_on_ros2_msgs.msg import Keypoints
            self.Keypoints = Keypoints
        except ImportError:
            self.get_logger().error('无法导入 track_on_ros2_msgs，请先构建并 source 工作空间')
            raise
        self.keypoints_pub = self.create_publisher(self.Keypoints, 'tracking/keypoints', 10)

        # 可视化发布
        if publish_visualization:
            self.vis_image_pub = self.create_publisher(Image, 'tracking/visualization', 10)
        else:
            self.vis_image_pub = None

        # 服务
        try:
            from track_on_ros2_srv.srv import SetKeypoints, ControlTracking, ResetTracking
        except ImportError:
            self.get_logger().error('无法导入 track_on_ros2_srv，请先构建并 source 工作空间')
            raise
        self.set_keypoints_srv = self.create_service(SetKeypoints, 'tracking/set_keypoints', self.set_keypoints_callback)
        self.control_tracking_srv = self.create_service(ControlTracking, 'tracking/control', self.control_tracking_callback)
        self.reset_tracking_srv = self.create_service(ResetTracking, 'tracking/reset', self.reset_tracking_callback)

        # 交互窗口
        if self.show_interactive_window:
            cv2.namedWindow(self.window_name)
            cv2.setMouseCallback(self.window_name, self.mouse_callback)
            self.get_logger().info('交互窗口已启用: 点击添加点, 空格开始, r重置, q退出')

        self.get_logger().info('前端摄像头最简跟踪节点已启动')

    def mouse_callback(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN and not self.tracking_started:
            self.selected_points.append([x, y])
            self.get_logger().info(f'已选择点 {len(self.selected_points)}: ({x}, {y})')

    def _generate_colors(self, num_colors):
        cmap = plt.cm.get_cmap('tab20', min(num_colors, 20))
        colors = []
        for i in range(num_colors):
            rgba = cmap(i % cmap.N)
            bgr = (int(rgba[2] * 255), int(rgba[1] * 255), int(rgba[0] * 255))
            colors.append(bgr)
        return colors

    def image_callback(self, msg: Image):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            self.process_frame(cv_image, msg.header)
        except Exception as e:
            self.get_logger().error(f'处理图像消息时出错: {e}')

    def process_frame(self, frame, header: Header):
        self.current_frame = frame.copy()
        display_frame = frame.copy()

        if not self.tracking_started:
            # 显示已选择的点
            for i, point in enumerate(self.selected_points):
                x, y = int(point[0]), int(point[1])
                color = self.colors[i % len(self.colors)]
                cv2.circle(display_frame, (x, y), 8, color, -1)
                cv2.putText(display_frame, f"{i+1}", (x+10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            tip = (
                f"Selected {len(self.selected_points)} points. Press SPACE to start tracking"
                if self.show_interactive_window else
                f"Selected {len(self.selected_points)} points. Call /tracking/control to start"
            ) if len(self.selected_points) > 0 else (
                "Click to select points, then press SPACE" if self.show_interactive_window else
                "Call /tracking/set_keypoints to select points"
            )
            cv2.putText(display_frame, tip, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0) if len(self.selected_points)>0 else (0,255,255), 2)
        else:
            # 跟踪模式
            if not self.first_frame_captured and len(self.selected_points) > 0:
                # 初始化跟踪
                queries = np.array(self.selected_points, dtype=np.float32)
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                try:
                    init_out = self.tracker.initialize_tracking(queries, frame_rgb)
                    # 兼容返回超过两个元素的情况，只取前两个(points, visibility)
                    if isinstance(init_out, (list, tuple)) and len(init_out) >= 2:
                        points = np.array(init_out[0], dtype=np.float32)
                        visibility = np.array(init_out[1], dtype=bool)
                    else:
                        points, visibility = init_out
                    self.first_frame_captured = True
                    self.get_logger().info(f'跟踪已初始化，共 {len(queries)} 个关键点')
                    self.publish_keypoints(points, visibility, header)
                    # 实时打印2D坐标
                    self._maybe_log_xy(points, visibility)
                except Exception as e:
                    self.get_logger().error(f'初始化跟踪时出错: {e}')
                    import traceback
                    self.get_logger().error(traceback.format_exc())
                    self.tracking_started = False
                    return
            if self.first_frame_captured:
                # 跟踪下一帧
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                try:
                    out = self.tracker.track_next_frame(frame_rgb)
                    if isinstance(out, (list, tuple)) and len(out) >= 2:
                        points = np.array(out[0], dtype=np.float32)
                        visibility = np.array(out[1], dtype=bool)
                    else:
                        points, visibility = out
                    # 绘制跟踪结果
                    for i in range(len(points)):
                        x, y = int(points[i, 0]), int(points[i, 1])
                        color = self.colors[i % len(self.colors)]
                        if visibility[i]:
                            cv2.circle(display_frame, (x, y), 8, color, -1)
                            cv2.circle(display_frame, (x, y), 12, color, 2)
                        else:
                            cv2.circle(display_frame, (x, y), 8, color, 2)
                        cv2.putText(display_frame, f"{i+1}", (x+10, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                    cv2.putText(display_frame, f"Frame: {self.frame_count}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
                    self.publish_keypoints(points, visibility, header)
                    # 实时打印2D坐标
                    self._maybe_log_xy(points, visibility)
                    self.frame_count += 1
                except Exception as e:
                    self.get_logger().error(f'跟踪时出错: {e}')
                    import traceback
                    self.get_logger().error(traceback.format_exc())

        # 显示窗口并处理键盘输入
        if self.show_interactive_window:
            cv2.imshow(self.window_name, display_frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                self.get_logger().info('收到退出信号 (q键)')
                self.should_exit = True
            elif key == ord(' '):
                if len(self.selected_points) > 0 and not self.tracking_started:
                    self.tracking_started = True
                    self.first_frame_captured = False
                    self.frame_count = 0
                    self.get_logger().info('开始跟踪...')
                elif self.tracking_started:
                    self.get_logger().info('跟踪已在进行中...')
                else:
                    self.get_logger().warn('请先选择至少一个关键点')
            elif key == ord('r'):
                if self.tracking_started:
                    self.tracker.reset()
                self.tracking_started = False
                self.first_frame_captured = False
                self.selected_points = []
                self.frame_count = 0
                self.get_logger().info('已重置，请重新选择关键点')

        # 发布可视化图像
        if self.vis_image_pub is not None:
            try:
                vis_msg = self.bridge.cv2_to_imgmsg(display_frame, encoding='bgr8')
                vis_msg.header = header
                self.vis_image_pub.publish(vis_msg)
            except Exception as e:
                self.get_logger().error(f'发布可视化图像时出错: {e}')

    def publish_keypoints(self, points, visibility, header):
        from track_on_ros2_msgs.msg import Keypoint
        keypoints_msg = self.Keypoints()
        keypoints_msg.header = header
        keypoints_msg.num_keypoints = len(points)
        for i in range(len(points)):
            kp = Keypoint()
            kp.id = i
            kp.x = float(points[i, 0])
            kp.y = float(points[i, 1])
            kp.visible = bool(visibility[i])
            keypoints_msg.keypoints.append(kp)
        self.keypoints_pub.publish(keypoints_msg)

    def _maybe_log_xy(self, points: np.ndarray, visibility: np.ndarray):
        if not getattr(self, 'print_xy', False):
            return
        self.print_xy_counter += 1
        if self.print_xy_counter % self.print_xy_interval != 0:
            return
        logs = []
        try:
            n = len(points)
            for i in range(n):
                vis = bool(visibility[i]) if i < len(visibility) else True
                if vis:
                    x = float(points[i, 0]); y = float(points[i, 1])
                    logs.append(f"点{i+1}: x={x:.1f}, y={y:.1f}")
                else:
                    logs.append(f"点{i+1}: 不可见")
        except Exception:
            return
        if logs:
            self.get_logger().info("关键点2D坐标: " + " | ".join(logs))

    def set_keypoints_callback(self, request, response):
        if self.tracking_started:
            response.success = False
            response.message = "跟踪已在进行中，请先重置"
            return response
        if self.current_frame is None:
            response.success = False
            response.message = "没有可用的图像帧"
            return response
        if len(request.x) != len(request.y):
            response.success = False
            response.message = "x和y坐标数量不匹配"
            return response
        h, w = self.current_frame.shape[:2]
        self.selected_points = []
        for i in range(len(request.x)):
            x, y = request.x[i], request.y[i]
            if 0 <= x < w and 0 <= y < h:
                self.selected_points.append([x, y])
            else:
                self.get_logger().warn(f'关键点 ({x}, {y}) 超出图像范围 ({w}, {h})，已忽略')
        if len(self.selected_points) == 0:
            response.success = False
            response.message = "没有有效的关键点"
            return response
        response.success = True
        response.message = f"已设置 {len(self.selected_points)} 个关键点"
        self.get_logger().info(response.message)
        return response

    def control_tracking_callback(self, request, response):
        if request.command == "start":
            if len(self.selected_points) == 0:
                response.success = False
                response.message = "请先设置关键点"
                return response
            if self.tracking_started:
                response.success = False
                response.message = "跟踪已在进行中"
                return response
            self.tracking_started = True
            self.first_frame_captured = False
            self.frame_count = 0
            response.success = True
            response.message = "跟踪已开始"
            self.get_logger().info(response.message)
        elif request.command == "stop":
            if not self.tracking_started:
                response.success = False
                response.message = "跟踪未在进行中"
                return response
            self.tracking_started = False
            response.success = True
            response.message = "跟踪已停止"
            self.get_logger().info(response.message)
        else:
            response.success = False
            response.message = f"未知命令: {request.command}，支持的命令: start, stop"
        return response

    def reset_tracking_callback(self, request, response):
        if self.tracking_started:
            self.tracker.reset()
        self.tracking_started = False
        self.first_frame_captured = False
        self.selected_points = []
        self.frame_count = 0
        response.success = True
        response.message = "跟踪已重置"
        self.get_logger().info(response.message)
        return response

    def destroy_node(self):
        if self.show_interactive_window:
            cv2.destroyAllWindows()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    try:
        node = TrackCameraFrontMinNode()
        if node.show_interactive_window:
            while rclpy.ok() and not node.should_exit:
                rclpy.spin_once(node, timeout_sec=0.01)
        else:
            rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f'节点运行出错: {e}')
        import traceback
        traceback.print_exc()
    finally:
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

